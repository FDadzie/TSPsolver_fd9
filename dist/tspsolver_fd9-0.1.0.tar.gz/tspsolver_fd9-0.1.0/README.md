A library for solving the Traveling Salesman Problem using Hill Climbing, Simulated Annealing, A * Search, and Random Search.
